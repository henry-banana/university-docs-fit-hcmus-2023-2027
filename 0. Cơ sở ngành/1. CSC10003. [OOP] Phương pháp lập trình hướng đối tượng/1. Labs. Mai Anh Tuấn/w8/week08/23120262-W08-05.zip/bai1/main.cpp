#include "NhanVienKyThuat.h"

int main() {
    NhanVienKyThuat nvkt("Nguyen Van A", "Nguyen Van Cu, Q. 5", "CNTT");
    std::cout << nvkt << "\n\n";
    return 0;
}
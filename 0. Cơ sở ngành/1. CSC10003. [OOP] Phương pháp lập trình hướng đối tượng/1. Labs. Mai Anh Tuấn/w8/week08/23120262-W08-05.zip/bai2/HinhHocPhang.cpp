#include "HinhHocPhang.h"

HinhHocPhang::HinhHocPhang() {}

float HinhHocPhang::TinhDienTich() {
    return 0;
}
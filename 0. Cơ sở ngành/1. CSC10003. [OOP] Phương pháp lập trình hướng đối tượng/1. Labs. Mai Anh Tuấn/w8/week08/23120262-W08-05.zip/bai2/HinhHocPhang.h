#ifndef HINHHOCPHANG_H
#define HINHHOCPHANG_H

class HinhHocPhang {
public:
    HinhHocPhang();
    virtual ~HinhHocPhang() {}

    virtual float TinhDienTich();
};

#endif
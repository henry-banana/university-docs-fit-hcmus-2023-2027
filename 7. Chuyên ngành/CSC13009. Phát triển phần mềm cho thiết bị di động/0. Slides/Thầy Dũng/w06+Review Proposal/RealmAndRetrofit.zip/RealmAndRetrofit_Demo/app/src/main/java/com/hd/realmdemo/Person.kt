package com.hd.realmdemo
import io.realm.kotlin.types.RealmObject

class Person : RealmObject {
    var name: String = "Foo"
    var dog: Dog? = null
}

class Dog : RealmObject {
    var name: String = ""
    var age: Int = 0
}
package com.hd.realmdemo

import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.Objects


class HttpHeaderInterceptor : Interceptor {
    private val headers: MutableMap<String, String> = HashMap()

    //Some header
    fun addHeader(token: String): HttpHeaderInterceptor {
//        headers["Postman-Token"] = token
//        headers["Host"] = "api.vdtdata.com"
//        headers["User-Agent"] = "PostmanRuntime/7.39.0"
//        headers["Content-Type"] = "application/json"
//        headers["Connection"] = "keep-alive"
        headers["Authorization"] = "Client-ID 11978402123e"
        return this
    }

    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val builder: Request.Builder = chain.request().newBuilder()
        for (key in headers.keys) {
            Objects.requireNonNull(headers[key])?.let { builder.addHeader(key, it) }
        }
        val response: Response
        try {
            response = chain.proceed(builder.build())
        } catch (e: Exception) {
            e.printStackTrace()
            throw e
        }
        return response
    }
}

package com.hd.realmdemo

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.gson.JsonObject
import io.realm.kotlin.Realm
import io.realm.kotlin.RealmConfiguration
import io.realm.kotlin.ext.query
import io.realm.kotlin.notifications.InitialResults
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        openDatabase()
        //testRetrofit1()
        testRetrofit2()
        readAsync()
    }

    val REALM_NAME = "HD_REALM_NAME"
    lateinit  var realm : Realm

    //Open Database
    fun openDatabase(){
        val configuration = RealmConfiguration.Builder(
            setOf(Person::class, Dog::class))
            .name(REALM_NAME).build()
        // specify name so realm doesn't just use
        // the "default.realm" file

        realm = Realm.open(configuration)
        Log.i("hdlog",realm.configuration.path)
        ///data/user/0/com.nlhdung.realmapp/files/HD_REALM_NAME

        writPerson()
        readAllWithName("Dung Nguyen")
    }

    fun writPerson(){
        // plain old kotlin object
        val person = Person().apply {
            name = "Dung Nguyen"
            dog = Dog().apply { name = "Fido"; age = 2 }
        }

        // persist it in a transaction
        realm.writeBlocking {
            val managedPerson = this.copyToRealm(person)
            Log.i("hdlog","Wrote " + managedPerson.name)
        }
    }
    fun readAllWithName(name: String){
        val all = realm.query<Person>().find()
        Log.i("hdlog","Read " + all.size + " elements")

        // Persons named 'Dung'
        //val personsByNameQuery = realm.query<Person>("name = $0", name)
        val personsByNameQuery = realm.query<Person>("name contains $0",
            name)
        val filteredPersons = personsByNameQuery.find()
        Log.i("hdlog","Read " + filteredPersons.toString())
    }
    fun readAndUpdate(term: String, newName: String){
        val personsByNameQuery = realm.query<Person>("name contains $0",
            term)
        val filteredPerson = personsByNameQuery.find().first()

        realm.writeBlocking{
            findLatest(filteredPerson)?.name = newName
        }
    }
    fun deletePersons(){
        realm.writeBlocking {
            val results = realm.query<Person>().find()
            results.forEach { delete(findLatest(it)!!) }
        }
    }
    fun readAsync(){
        val personsByNameQuery = realm.query<Person>("name contains $0", "Dung")

        val pObserver = GlobalScope.async {
            personsByNameQuery.asFlow().collect { results ->

                when (results) {
                    is InitialResults<Person> -> {
                        for (p in results.list) {
                            Log.i("hdlog","Info async:" + p.toString())
                        }
                    }
                    else -> { /* no-op */ }
                }

            }
        }

        // ... Later, cancel the Flow, so you can safely close the database
        //pObserver.cancel()
        //realm.close()
    }
    //Without Header
    fun testRetrofit1(){
        val apiInterface = ApiInterface.create("").getResources()
        apiInterface.enqueue( object : Callback<List<ResourceInfo>> {
            override fun onResponse(call: Call<List<ResourceInfo>>?, response: Response<List<ResourceInfo>>?) {
                if(response?.body() != null) {
                    var resourceList: List<ResourceInfo> = response.body()!!
                    Log.i("nlhdung", resourceList.get(0).toString())
                }
            }

            override fun onFailure(p0: Call<List<ResourceInfo>>, p1: Throwable) {
                Log.i("nlhdung","onFailure"); //t.message
            }
        })
    }

    //Without Header - API, Token...
    fun testRetrofit2(){
        val apiInterface = ImgurApiInterface.create("").getUser()
        apiInterface.enqueue( object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>?, response: Response<JsonObject>?) {
                if(response?.body() != null) {
                    var jsonData: String = response.body()!!.toString()
                    Log.i("nlhdung", jsonData)
                }
            }

            override fun onFailure(p0: Call<JsonObject>, p1: Throwable) {
                Log.i("nlhdung","onFailure"); //t.message
            }
        })
    }
}
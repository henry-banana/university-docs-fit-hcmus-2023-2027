package com.hd.realmdemo

import io.realm.kotlin.mongodb.auth.ApiKey
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager


interface ApiInterface {
    @GET("codingResources")
    fun getResources() : Call<List<ResourceInfo>>

    companion object {
        var BASE_URL =
        "https://api.sampleapis.com/codingresources/"
        fun create(token: String) : ApiInterface {
            val retrofit =
                Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory .create())
                .baseUrl(BASE_URL)
                .build()
            return retrofit.create(ApiInterface::class.java)
        }
    }



}
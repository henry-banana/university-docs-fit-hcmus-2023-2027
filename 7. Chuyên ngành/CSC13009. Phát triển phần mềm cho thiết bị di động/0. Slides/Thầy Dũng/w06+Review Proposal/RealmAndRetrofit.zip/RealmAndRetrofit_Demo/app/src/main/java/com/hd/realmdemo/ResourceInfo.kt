package com.hd.realmdemo

data class ResourceInfo(
    val id: String,
    val description: String,
    val url: String,
    val types: List<String>,
    val topics: List<String>,
    val levels: List<String>
)
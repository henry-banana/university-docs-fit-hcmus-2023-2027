package com.hd.realmdemo

import com.google.gson.JsonObject
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager


interface ImgurApiInterface {
    @GET("account/nlhdung")
    fun getUser() : Call<JsonObject>

    companion object {
        var BASE_URL =
        "https://api.imgur.com/3/"
        fun create(token: String) : ImgurApiInterface {
            val retrofit =
                Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory .create())
                .client(
                    getUnsafeHttpClient(
                        HttpHeaderInterceptor().addHeader(token)
                    ).build()
                )
                .baseUrl(BASE_URL)
                .build()
            return retrofit.create(ImgurApiInterface::class.java)
        }


        private fun getUnsafeHttpClient(headers: HttpHeaderInterceptor?): OkHttpClient.Builder {
            try {
                // Create a trust manager that does not validate certificate chains
                val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                    override fun checkClientTrusted(
                        chain: Array<X509Certificate>,
                        authType: String
                    ) {
                    }

                    override fun checkServerTrusted(
                        chain: Array<X509Certificate>,
                        authType: String
                    ) {
                    }

                    override fun getAcceptedIssuers(): Array<X509Certificate> {
                        return arrayOf()
                    }
                }
                )

                val interceptor = HttpLoggingInterceptor()
                // Install the all-trusting trust manager
                val sslContext = SSLContext.getInstance("SSL")
                sslContext.init(null, trustAllCerts, SecureRandom())

                // Create an ssl socket factory with our all-trusting manager
                val sslSocketFactory = sslContext.socketFactory

                val builder: OkHttpClient.Builder = OkHttpClient.Builder()
                builder.sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)

                builder.callTimeout(2, TimeUnit.MINUTES)
                builder.connectTimeout(20, TimeUnit.SECONDS)
                builder.readTimeout(30, TimeUnit.SECONDS)
                builder.writeTimeout(30, TimeUnit.SECONDS)
                if (headers != null) {
                    builder.addInterceptor(headers)
                }

                builder.addInterceptor(interceptor)
                builder.hostnameVerifier(HostnameVerifier { hostname, session -> true })
                return builder
            } catch (e: Exception) {
                throw RuntimeException(e)
            }
        }
    }



}
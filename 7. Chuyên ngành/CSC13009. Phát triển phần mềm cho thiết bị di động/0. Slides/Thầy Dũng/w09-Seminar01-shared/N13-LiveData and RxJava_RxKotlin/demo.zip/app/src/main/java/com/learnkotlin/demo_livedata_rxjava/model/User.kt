package com.learnkotlin.demo_livedata_rxjava

/**
 * Data class đại diện cho User
 */
data class User(
    val id: Int,
    val name: String,
    val email: String,
    val role: String,
    val department: String
)

/**
 * Sealed class để quản lý các trạng thái UI
 */
sealed class UiState<out T> {
    object Idle : UiState<Nothing>()
    object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}
package com.learnkotlin.demo_livedata_rxjava

import com.learnkotlin.demo_livedata_rxjava.User
import io.reactivex.rxjava3.core.Observable
import java.util.concurrent.TimeUnit

/**
 * Repository sử dụng RxJava để xử lý dữ liệu
 * Demo các toán tử: map, filter, delay, merge
 */
class UserRepository {

    // Danh sách user giả lập
    private val allUsers = listOf(
        User(1, "Nguyễn Văn Khang", "khang.nguyen@email.com", "Admin", "IT"),
        User(2, "Trần Thị Bình", "binh.tran@email.com", "User", "HR"),
        User(3, "Lê Văn Cường", "cuong.le@email.com", "Manager", "Sales"),
        User(4, "Phạm Thị Dung", "dung.pham@email.com", "User", "IT"),
        User(5, "Hoàng Văn Em", "em.hoang@email.com", "User", "Marketing"),
        User(6, "Võ Thị Phượng", "phuong.vo@email.com", "Admin", "IT"),
        User(7, "Đặng Văn Giang", "giang.dang@email.com", "User", "Sales"),
        User(8, "Bùi Thị Hương", "huong.bui@email.com", "Manager", "HR"),
        User(9, "Ngô Văn Linh", "linh.ngo@email.com", "User", "Marketing"),
        User(10, "Đinh Thị Khánh", "khanh.dinh@email.com", "User", "IT")
    )

    /**
     * Tìm kiếm user với RxJava
     * Demo toán tử: map (chuyển đổi), filter (lọc)
     * Giả lập delay để có cảm giác gọi API
     */
    fun searchUsers(query: String): Observable<List<User>> {
        return Observable.just(query)
            .delay(500, TimeUnit.MILLISECONDS) // Giả lập network delay
            .map { searchQuery -> searchQuery.lowercase().trim() } // Chuyển về chữ thường
            .map { searchQuery ->
                if (searchQuery.isEmpty()) {
                    allUsers // Trả về tất cả nếu query rỗng
                } else {
                    // Lọc user theo tên hoặc email
                    allUsers.filter { user ->
                        user.name.lowercase().contains(searchQuery) ||
                                user.email.lowercase().contains(searchQuery) ||
                                user.department.lowercase().contains(searchQuery)
                    }
                }
            }
    }

    /**
     * Lấy chi tiết user theo ID
     * Demo việc xử lý đơn giản với RxJava
     */
    fun getUserById(id: Int): Observable<User> {
        return Observable.just(id)
            .delay(300, TimeUnit.MILLISECONDS)
            .map { userId ->
                allUsers.find { it.id == userId }
                    ?: throw Exception("User không tồn tại")
            }
    }

    /**
     * Giả lập gọi API trả về tên user (dùng trong demo map)
     */
    fun getUserNameApi(): Observable<String> {
        // Trả về tên user đầu tiên để demo; giả lập delay
        return Observable.just(allUsers.first().name)
            .delay(400, TimeUnit.MILLISECONDS)
    }

    /**
     * Giả lập nguồn cache trả về role của user (dùng trong demo merge)
     */
    fun getUserRoleCache(): Observable<String> {
        // Trả về role của user đầu tiên để demo
        return Observable.just(" (${allUsers.first().role})")
    }

    /**
     * Demo toán tử MERGE: Lấy thông tin từ nhiều nguồn
     * Giả lập lấy thông tin cơ bản và thông tin bổ sung
     */
    fun getUserWithDetails(id: Int): Observable<String> {
        val basicInfo = Observable.just("Thông tin cơ bản: User #$id")
            .delay(300, TimeUnit.MILLISECONDS)

        val additionalInfo = Observable.just("Đã xác thực ✓")
            .delay(500, TimeUnit.MILLISECONDS)

        return Observable.merge(basicInfo, additionalInfo)
    }

    /**
     * Lấy tổng số user theo department
     * Demo toán tử groupBy và count
     */
    fun getUserStatistics(): Observable<Map<String, Int>> {
        return Observable.fromIterable(allUsers)
            .groupBy { it.department }
            .flatMap { group ->
                group.count().map { count ->
                    requireNotNull(group.key) to count.toInt()
                }.toObservable()
            }
            .toList()
            .map { it.toMap() }
            .toObservable()
    }
}
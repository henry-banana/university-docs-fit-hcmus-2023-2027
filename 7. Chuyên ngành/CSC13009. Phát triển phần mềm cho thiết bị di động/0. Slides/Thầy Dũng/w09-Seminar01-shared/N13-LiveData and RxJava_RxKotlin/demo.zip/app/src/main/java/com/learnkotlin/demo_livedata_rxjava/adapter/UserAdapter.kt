package com.learnkotlin.demo_livedata_rxjava

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.learnkotlin.demo_livedata_rxjava.R
import com.learnkotlin.demo_livedata_rxjava.User

/**
 * Adapter cho RecyclerView hiển thị danh sách User
 */
class UserAdapter(
    private val onUserClick: (User) -> Unit
) : ListAdapter<User, UserAdapter.UserViewHolder>(UserDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = getItem(position)
        holder.bind(user)
    }

    inner class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tvUserName)
        private val tvEmail: TextView = itemView.findViewById(R.id.tvUserEmail)
        private val tvRole: TextView = itemView.findViewById(R.id.tvUserRole)
        private val tvDepartment: TextView = itemView.findViewById(R.id.tvUserDepartment)

        fun bind(user: User) {
            tvName.text = user.name
            tvEmail.text = user.email
            tvRole.text = user.role
            tvDepartment.text = user.department

            itemView.setOnClickListener {
                onUserClick(user)
            }
        }
    }
}

/**
 * DiffUtil để tối ưu performance khi update list
 */
class UserDiffCallback : DiffUtil.ItemCallback<User>() {
    override fun areItemsTheSame(oldItem: User, newItem: User): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: User, newItem: User): Boolean {
        return oldItem == newItem
    }
}
package com.learnkotlin.demo_livedata_rxjava

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.learnkotlin.demo_livedata_rxjava.UserAdapter
import com.learnkotlin.demo_livedata_rxjava.databinding.ActivityMainBinding
import com.learnkotlin.demo_livedata_rxjava.UiState
import com.learnkotlin.demo_livedata_rxjava.User
import com.learnkotlin.demo_livedata_rxjava.UserViewModel

/**
 * MainActivity - Demo LiveData observe UI updates
 * Kết hợp RxJava (ViewModel) và LiveData (UI)
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: UserViewModel by viewModels()
    private lateinit var userAdapter: UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // DataBinding: set lifecycleOwner and viewModel for two-way binding
        binding.lifecycleOwner = this
        binding.viewModel = viewModel

        setupRecyclerView()
        setupSearchInput()
        setupDemoButtons()
        observeViewModel()
    }

    /**
     * Setup RecyclerView
     */
    private fun setupRecyclerView() {
        userAdapter = UserAdapter { user ->
            showUserDetails(user)
        }

        binding.recyclerViewUsers.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = userAdapter
        }
    }

    /**
     * Setup search input với TextWatcher
     * Mỗi lần thay đổi text -> gọi ViewModel
     */
    private fun setupSearchInput() {
        // Two-way bound EditText updates viewModel.userInput automatically.
        // Observe userInput and forward to search logic (so UI->ViewModel flow is shown)
        viewModel.userInput.observe(this) { query ->
            viewModel.onSearchQueryChanged(query ?: "")
        }

        // Ensure initial load
        if (viewModel.userInput.value.isNullOrEmpty()) {
            viewModel.userInput.value = ""
            viewModel.onSearchQueryChanged("")
        } else {
            viewModel.onSearchQueryChanged(viewModel.userInput.value ?: "")
        }
    }

    /**
     * Setup demo buttons to trigger Rx examples and show results via LiveData
     */
    private fun setupDemoButtons() {
        binding.btnDemoMap.setOnClickListener {
            viewModel.demoMap()
        }
        binding.btnDemoMerge.setOnClickListener {
            viewModel.demoMerge()
        }
    }

    /**
     * Observe LiveData từ ViewModel
     * Demo lifecycle-aware: chỉ update UI khi Activity ACTIVE
     */
    private fun observeViewModel() {
        // Observe danh sách users
        viewModel.usersState.observe(this) { state ->
            when (state) {
                is UiState.Idle -> {
                    hideLoading()
                }
                is UiState.Loading -> {
                    showLoading()
                }
                is UiState.Success -> {
                    hideLoading()
                    updateUserList(state.data)
                }
                is UiState.Error -> {
                    hideLoading()
                    showError(state.message)
                }

                else -> {}
            }
        }

        // Observe statistics
        viewModel.statistics.observe(this) { stats ->
            updateStatistics(stats)
        }

        // Observe demo outputs (map / merge) to illustrate LiveData syncing UI
        viewModel.demoText.observe(this) { text ->
            updateDemoOutput(text)
        }

        viewModel.demoMerged.observe(this) { text ->
            updateDemoOutput(text)
        }
    }

    /**
     * Update danh sách user vào RecyclerView
     */
    private fun updateUserList(users: List<User>) {
        if (users.isEmpty()) {
            binding.tvEmptyState.visibility = View.VISIBLE
            binding.recyclerViewUsers.visibility = View.GONE
        } else {
            binding.tvEmptyState.visibility = View.GONE
            binding.recyclerViewUsers.visibility = View.VISIBLE
            userAdapter.submitList(users)
        }

        binding.tvResultCount.text = "Tìm thấy ${users.size} user"
    }

    /**
     * Hiển thị chi tiết user khi click
     */
    private fun showUserDetails(user: User) {
        val message = """
            ID: ${user.id}
            Tên: ${user.name}
            Email: ${user.email}
            Vai trò: ${user.role}
            Phòng ban: ${user.department}
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Chi tiết User")
            .setMessage(message)
            .setPositiveButton("Đóng", null)
            .show()
    }

    /**
     * Update thống kê
     */
    private fun updateStatistics(stats: Map<String, Int>) {
        val statsText = stats.entries.joinToString("\n") { (dept, count) ->
            "$dept: $count người"
        }
        binding.tvStatistics.text = "Thống kê theo phòng ban:\n$statsText"
    }

    /**
     * Update demo output area
     */
    private fun updateDemoOutput(text: String) {
        binding.tvDemoOutput.text = text
    }

    /**
     * Hiển thị loading
     */
    private fun showLoading() {
        binding.progressBar.visibility = View.VISIBLE
    }

    /**
     * Ẩn loading
     */
    private fun hideLoading() {
        binding.progressBar.visibility = View.GONE
    }

    /**
     * Hiển thị lỗi
     */
    private fun showError(message: String) {
        Toast.makeText(this, "Lỗi: $message", Toast.LENGTH_SHORT).show()
    }
}
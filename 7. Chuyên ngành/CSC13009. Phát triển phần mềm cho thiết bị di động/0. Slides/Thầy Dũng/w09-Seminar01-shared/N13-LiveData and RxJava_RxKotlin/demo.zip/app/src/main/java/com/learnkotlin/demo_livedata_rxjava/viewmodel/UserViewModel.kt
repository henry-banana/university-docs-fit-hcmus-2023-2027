package com.learnkotlin.demo_livedata_rxjava

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.learnkotlin.demo_livedata_rxjava.UiState
import com.learnkotlin.demo_livedata_rxjava.User
import com.learnkotlin.demo_livedata_rxjava.UserRepository
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.disposables.CompositeDisposable
import io.reactivex.rxjava3.schedulers.Schedulers
import io.reactivex.rxjava3.subjects.PublishSubject
import java.util.concurrent.TimeUnit

/**
 * ViewModel kết hợp RxJava và LiveData
 * - RxJava xử lý logic phức tạp (debounce, search)
 * - LiveData expose dữ liệu cho UI (lifecycle-aware)
 */
class UserViewModel : ViewModel() {

    private val repository = UserRepository()
    private val disposables = CompositeDisposable()

    // PublishSubject từ RxJava để handle search input
    private val searchSubject = PublishSubject.create<String>()

    // LiveData để UI observe (Lifecycle-aware)
    private val _usersState = MutableLiveData<UiState<List<User>>>()
    val usersState: LiveData<UiState<List<User>>> = _usersState

    private val _selectedUser = MutableLiveData<User?>()
    val selectedUser: LiveData<User?> = _selectedUser

    private val _statistics = MutableLiveData<Map<String, Int>>()
    val statistics: LiveData<Map<String, Int>> = _statistics

    // Two-way binding sample: user input bound to EditText in layout
    val userInput = MutableLiveData<String>("")

    init {
        setupSearch()
        loadStatistics()
    }

    /**
     * Setup search với debounce sử dụng RxJava
     * Tránh gọi API liên tục khi user đang gõ
     */
    private fun setupSearch() {
        val disposable = searchSubject
            .debounce(400, TimeUnit.MILLISECONDS) // Đợi 400ms sau khi user ngừng gõ
            .distinctUntilChanged() // Chỉ emit khi query thay đổi
            .doOnNext { _usersState.postValue(UiState.Loading) } // Set loading state
            .switchMap { query ->
                repository.searchUsers(query)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .onErrorReturn { emptyList() } // Xử lý lỗi trả về list rỗng
            }
            .subscribe(
                { users ->
                    // Success: Update LiveData
                    _usersState.value = UiState.Success(users)
                },
                { error ->
                    // Error: Update LiveData với error state
                    _usersState.value = UiState.Error(error.message ?: "Lỗi không xác định")
                }
            )

        disposables.add(disposable)
    }

    /**
     * Function được gọi từ UI khi user nhập search query
     */
    fun onSearchQueryChanged(query: String) {
        searchSubject.onNext(query)
    }

    /**
     * Load chi tiết user
     */
    fun loadUserDetails(userId: Int) {
        val disposable = repository.getUserById(userId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { user ->
                    _selectedUser.value = user
                },
                { error ->
                    _selectedUser.value = null
                }
            )

        disposables.add(disposable)
    }

    /**
     * Load thống kê - Demo toán tử phức tạp của RxJava
     */
    private fun loadStatistics() {
        val disposable = repository.getUserStatistics()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { stats ->
                    _statistics.value = stats
                },
                { error ->
                    // Handle error
                }
            )

        disposables.add(disposable)
    }

    /**
     * Clear selected user
     */
    fun clearSelectedUser() {
        _selectedUser.value = null
    }

    /**
     * Demo LiveData outputs to illustrate sync between RxJava logic and LiveData
     */
    private val _demoText = MutableLiveData<String>()
    val demoText: LiveData<String> = _demoText

    private val _demoMerged = MutableLiveData<String>()
    val demoMerged: LiveData<String> = _demoMerged

    /**
     * Demo map operator: uppercase result from API and post to LiveData
     */
    fun demoMap() {
        val disposable = repository.getUserNameApi()
            .subscribeOn(Schedulers.io())
            .map { it.uppercase() }
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    _demoText.value = "Map result: $result"
                },
                { error ->
                    _demoText.value = "Map error: ${error.message}"
                }
            )
        disposables.add(disposable)
    }

    /**
     * Demo merge using zip: combine name + role and post to LiveData
     */
    fun demoMerge() {
        val disposable = io.reactivex.rxjava3.core.Observable.zip(
            repository.getUserNameApi(),
            repository.getUserRoleCache(),
            { name: String, role: String -> "$name$role" }
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { combined ->
                    _demoMerged.value = "Merge result: $combined"
                },
                { error ->
                    _demoMerged.value = "Merge error: ${error.message}"
                }
            )
        disposables.add(disposable)
    }

    /**
     * Dọn dẹp disposables khi ViewModel bị destroy
     */
    override fun onCleared() {
        super.onCleared()
        disposables.clear()
    }
}
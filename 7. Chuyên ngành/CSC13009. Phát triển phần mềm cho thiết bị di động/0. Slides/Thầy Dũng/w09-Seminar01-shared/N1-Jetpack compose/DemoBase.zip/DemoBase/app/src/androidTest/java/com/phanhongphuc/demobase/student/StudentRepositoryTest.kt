package com.phanhongphuc.demobase.student

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.google.common.truth.Truth.assertThat
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class StudentRepositoryTest {

    private lateinit var repository: StudentRepository
    private lateinit var context: Context
    private val fileName = "students.txt"

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        repository = StudentRepository(context)
        // Clean up before test
        File(context.filesDir, fileName).delete()
    }

    @After
    fun tearDown() {
        // Clean up after test
        File(context.filesDir, fileName).delete()
    }

    @Test
    fun saveStudent_addsNewStudent() {
        val student = Student("1", "Nguyen Van A", "01/01/2000", "ClassA", "Male")
        
        repository.saveStudent(student)
        
        val students = repository.getAllStudents()
        assertThat(students).hasSize(1)
        assertThat(students[0]).isEqualTo(student)
    }

    @Test
    fun saveStudent_updatesExistingStudent() {
        val student = Student("1", "Nguyen Van A", "01/01/2000", "ClassA", "Male")
        repository.saveStudent(student)
        
        val updatedStudent = student.copy(fullName = "Nguyen Van B")
        repository.saveStudent(updatedStudent)
        
        val students = repository.getAllStudents()
        assertThat(students).hasSize(1)
        assertThat(students[0].fullName).isEqualTo("Nguyen Van B")
    }

    @Test
    fun deleteStudent_removesStudent() {
        val student = Student("1", "Nguyen Van A", "01/01/2000", "ClassA", "Male")
        repository.saveStudent(student)
        
        repository.deleteStudent("1")
        
        val students = repository.getAllStudents()
        assertThat(students).isEmpty()
    }
    
    @Test
    fun getAllStudents_returnsSavedStudents() {
        val student1 = Student("1", "A", "d1", "c1", "m")
        val student2 = Student("2", "B", "d2", "c2", "f")
        
        repository.saveStudent(student1)
        repository.saveStudent(student2)
        
        val students = repository.getAllStudents()
        assertThat(students).hasSize(2)
        assertThat(students).containsExactly(student1, student2)
    }
}

package com.phanhongphuc.demobase.student

import java.util.UUID

data class Student(
    val id: String = UUID.randomUUID().toString(),
    val fullName: String,
    val birthday: String,
    val className: String,
    val gender: String
)

package com.phanhongphuc.demobase.student

import android.content.Context
import java.io.File

class StudentRepository(private val context: Context) {
    private val fileName = "students.txt"

    fun saveStudent(student: Student) {
        val students = getAllStudents().toMutableList()
        val existingIndex = students.indexOfFirst { it.id == student.id }
        if (existingIndex != -1) {
            students[existingIndex] = student
        } else {
            students.add(student)
        }
        saveAll(students)
    }

    fun deleteStudent(studentId: String) {
        val students = getAllStudents().filter { it.id != studentId }
        saveAll(students)
    }

    fun getAllStudents(): List<Student> {
        val file = File(context.filesDir, fileName)
        if (!file.exists()) return emptyList()

        return file.readLines().mapNotNull { line ->
            val parts = line.split("|")
            if (parts.size >= 5) {
                Student(
                    id = parts[0],
                    fullName = parts[1],
                    birthday = parts[2],
                    className = parts[3],
                    gender = parts[4]
                )
            } else null
        }
    }

    private fun saveAll(students: List<Student>) {
        val file = File(context.filesDir, fileName)
        file.printWriter().use { out ->
            students.forEach {
                out.println("${it.id}|${it.fullName}|${it.birthday}|${it.className}|${it.gender}")
            }
        }
    }
}

package com.phanhongphuc.demobase.student

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import com.phanhongphuc.demobase.ui.theme.DemoBaseTheme
import org.junit.Rule
import org.junit.Test

class StudentListScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private val sampleStudents = listOf(
        Student("1", "Nguyen Van A", "01/01/2000", "ClassA", "Male"),
        Student("2", "Tran Thi B", "02/02/2000", "ClassB", "Female")
    )

    @Test
    fun studentListContent_displaysStudents() {
        // Given
        val state = StudentListUiState(
            students = sampleStudents,
            filteredStudents = sampleStudents
        )

        // When
        composeTestRule.setContent {
            DemoBaseTheme {
                StudentListContent(
                    uiState = state,
                    onSearchQueryChange = {},
                    onToggleLayout = {},
                    onNavigateToDetail = {}
                )
            }
        }

        // Then
        composeTestRule.onNodeWithText("Nguyen Van A").assertIsDisplayed()
        composeTestRule.onNodeWithText("Tran Thi B").assertIsDisplayed()
    }

    @Test
    fun studentListContent_searchTriggersCallback() {
        // Given
        var searchQuery = ""
        val state = StudentListUiState(
            students = sampleStudents,
            filteredStudents = sampleStudents
        )

        // When
        composeTestRule.setContent {
            DemoBaseTheme {
                StudentListContent(
                    uiState = state,
                    onSearchQueryChange = { searchQuery = it },
                    onToggleLayout = {},
                    onNavigateToDetail = {}
                )
            }
        }

        // Action: Click search, type text
        // Note: SearchBar behavior might be tricky to test if it's inactive by default.
        // Assuming "Search students..." placeholder is visible when inactive.
        composeTestRule.onNodeWithText("Search students...")
            .performClick()
            .performTextInput("Nguyen")

        // Then
        // Depends on implementation, SearchBar might not trigger on text input immediately or might need explicit callback.
        // In StudentListScreen.kt:
        // SearchBar(query = uiState.searchQuery, onQueryChange = onSearchQueryChange, ...)
        // So typing should trigger onQueryChange directly.
        
        // Wait, performTextInput needs a focused node. performClick sets focus?
        // Let's assume standard SearchBar behavior.
        
        // Actually, assertions might be flaky if `searchQuery` update is not observed by the composable (since I passed static state).
        // But the callback `onSearchQueryChange` should fire.
        
        assert(searchQuery == "Nguyen")
    }

    @Test
    fun studentListContent_toggleLayoutTriggersCallback() {
        // Given
        var toggled = false
        val state = StudentListUiState()

        // When
        composeTestRule.setContent {
            DemoBaseTheme {
                StudentListContent(
                    uiState = state,
                    onSearchQueryChange = {},
                    onToggleLayout = { toggled = true },
                    onNavigateToDetail = {}
                )
            }
        }

        // Action
        composeTestRule.onNodeWithContentDescription("Toggle Layout")
            .performClick()

        // Then
        assert(toggled)
    }
}

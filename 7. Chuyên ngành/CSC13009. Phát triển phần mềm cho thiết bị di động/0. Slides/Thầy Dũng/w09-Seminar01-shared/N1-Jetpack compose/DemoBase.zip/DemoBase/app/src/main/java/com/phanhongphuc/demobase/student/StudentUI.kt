package com.phanhongphuc.demobase.student

import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun StudentApp() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val application = context.applicationContext as Application

    NavHost(navController = navController, startDestination = "list") {
        composable("list") {
            val listViewModel: StudentListViewModel = viewModel(
                factory = StudentListViewModelFactory(application)
            )
            StudentListScreen(
                viewModel = listViewModel,
                onNavigateToDetail = { studentId ->
                    navController.navigate("detail/$studentId")
                }
            )
        }
        composable("detail/{studentId}") { backStackEntry ->
            val studentId = backStackEntry.arguments?.getString("studentId") ?: "new"
            val detailViewModel: StudentDetailViewModel = viewModel(
                factory = StudentDetailViewModelFactory(application)
            )
            StudentDetailScreen(
                studentId = studentId,
                viewModel = detailViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}

package com.phanhongphuc.demobase

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.phanhongphuc.demobase.student.StudentApp
import com.phanhongphuc.demobase.ui.theme.DemoBaseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DemoBaseTheme {
                StudentApp()
            }
        }
    }
}

package com.phanhongphuc.demobase.student

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class StudentListUiState(
    val students: List<Student> = emptyList(),
    val filteredStudents: List<Student> = emptyList(),
    val searchQuery: String = "",
    val isGridLayout: Boolean = false
)

class StudentListViewModel(private val repository: StudentRepository) : ViewModel() {
    
    private val _uiState = MutableStateFlow(StudentListUiState())
    val uiState: StateFlow<StudentListUiState> = _uiState.asStateFlow()

    init {
        loadStudents()
    }

    fun loadStudents() {
        val students = repository.getAllStudents()
        _uiState.update { 
            it.copy(
                students = students,
                filteredStudents = filterStudents(students, it.searchQuery)
            ) 
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update {
            it.copy(
                searchQuery = query,
                filteredStudents = filterStudents(it.students, query)
            )
        }
    }

    private fun filterStudents(students: List<Student>, query: String): List<Student> {
        if (query.isBlank()) return students
        return students.filter {
            it.fullName.contains(query, ignoreCase = true) ||
            it.id.contains(query, ignoreCase = true)
        }
    }

    fun toggleLayout() {
        _uiState.update { it.copy(isGridLayout = !it.isGridLayout) }
    }
}

class StudentListViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudentListViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            val repository = StudentRepository(application)
            return StudentListViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

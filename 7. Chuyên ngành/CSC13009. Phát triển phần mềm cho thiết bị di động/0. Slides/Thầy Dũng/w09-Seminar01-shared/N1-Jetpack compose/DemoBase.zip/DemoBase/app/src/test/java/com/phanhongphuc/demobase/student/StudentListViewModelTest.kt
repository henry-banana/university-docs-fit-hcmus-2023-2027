package com.phanhongphuc.demobase.student

import com.google.common.truth.Truth.assertThat
import com.phanhongphuc.demobase.util.MainDispatcherRule
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.junit.Rule
import org.junit.Test

class StudentListViewModelTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private val repository: StudentRepository = mockk()
    private lateinit var viewModel: StudentListViewModel

    private val sampleStudents = listOf(
        Student("1", "Nguyen Van A", "01/01/2000", "ClassA", "Male"),
        Student("2", "Tran Thi B", "02/02/2000", "ClassB", "Female")
    )

    @Test
    fun loadStudents_initializesStateCorrectly() {
        // Given
        every { repository.getAllStudents() } returns sampleStudents

        // When
        viewModel = StudentListViewModel(repository)

        // Then
        val uiState = viewModel.uiState.value
        assertThat(uiState.students).isEqualTo(sampleStudents)
        assertThat(uiState.filteredStudents).isEqualTo(sampleStudents) // Should match initially
    }

    @Test
    fun setSearchQuery_filtersStudentsByName() {
        // Given
        every { repository.getAllStudents() } returns sampleStudents
        viewModel = StudentListViewModel(repository)

        // When
        viewModel.setSearchQuery("Nguyen")

        // Then
        val uiState = viewModel.uiState.value
        assertThat(uiState.searchQuery).isEqualTo("Nguyen")
        assertThat(uiState.filteredStudents).hasSize(1)
        assertThat(uiState.filteredStudents.first().fullName).isEqualTo("Nguyen Van A")
    }
    
    @Test
    fun setSearchQuery_filtersStudentsById() {
        // Given
        every { repository.getAllStudents() } returns sampleStudents
        viewModel = StudentListViewModel(repository)

        // When
        viewModel.setSearchQuery("2") // ID of second student

        // Then
        val uiState = viewModel.uiState.value
        assertThat(uiState.filteredStudents).hasSize(1)
        assertThat(uiState.filteredStudents.first().fullName).isEqualTo("Tran Thi B")
    }

    @Test
    fun toggleLayout_switchesGridLayout() {
        // Given
        every { repository.getAllStudents() } returns emptyList()
        viewModel = StudentListViewModel(repository)
        val initialLayout = viewModel.uiState.value.isGridLayout
        
        // When
        viewModel.toggleLayout()

        // Then
        assertThat(viewModel.uiState.value.isGridLayout).isNotEqualTo(initialLayout)
    }
}

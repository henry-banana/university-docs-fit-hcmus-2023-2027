package com.phanhongphuc.demobase.student

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

data class StudentDetailUiState(
    val id: String = "",
    val fullName: String = "",
    val birthday: String = "",
    val className: String = "",
    val gender: String = "",
    val availableClasses: List<String> = listOf("19KTPM1", "19KTPM2", "20KTPM1", "20KTPM2", "21KTPM1"),
    val isNew: Boolean = true
)

class StudentDetailViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = StudentRepository(application)

    private val _uiState = MutableStateFlow(StudentDetailUiState())
    val uiState: StateFlow<StudentDetailUiState> = _uiState.asStateFlow()

    fun initialize(studentId: String) {
        if (studentId == "new") {
            _uiState.update { 
                it.copy(
                    isNew = true,
                    id = UUID.randomUUID().toString(),
                    className = it.availableClasses.firstOrNull() ?: ""
                ) 
            }
        } else {
            val student = repository.getAllStudents().find { it.id == studentId }
            if (student != null) {
                _uiState.update {
                    it.copy(
                        isNew = false,
                        id = student.id,
                        fullName = student.fullName,
                        birthday = student.birthday,
                        className = student.className,
                        gender = student.gender
                    )
                }
            }
        }
    }

    fun updateFullName(name: String) {
        _uiState.update { it.copy(fullName = name) }
    }

    fun updateBirthday(birthday: String) {
        _uiState.update { it.copy(birthday = birthday) }
    }

    fun updateClassName(className: String) {
        _uiState.update { it.copy(className = className) }
    }

    fun updateGender(gender: String) {
        _uiState.update { it.copy(gender = gender) }
    }

    fun saveStudent() {
        val state = _uiState.value
        val student = Student(
            id = state.id,
            fullName = state.fullName,
            birthday = state.birthday,
            className = state.className,
            gender = state.gender
        )
        repository.saveStudent(student)
    }

    fun deleteStudent() {
        val state = _uiState.value
        if (!state.isNew) {
            repository.deleteStudent(state.id)
        }
    }
}

class StudentDetailViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudentDetailViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return StudentDetailViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

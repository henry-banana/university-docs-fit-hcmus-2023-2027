package com.example.agentdemo
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.Schema
import com.google.ai.client.generativeai.type.Tool
import com.google.ai.client.generativeai.type.defineFunction
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.FunctionResponsePart
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rootLayout = findViewById<LinearLayout>(R.id.rootLayout)
        val tvAiResponse = findViewById<TextView>(R.id.tvAiResponse)
        val edtInput = findViewById<EditText>(R.id.edtInput)
        val btnSend = findViewById<Button>(R.id.btnSend)

        val changeColorTool = defineFunction(
            name = "changeBackgroundColor",
            description = "Change the background color of the screen based on user mood or request",
            parameters = listOf(
                Schema.str("color", "The color name in English (red, blue, green, yellow, white, black, gray)")
            ),
            requiredParameters = listOf("color")
        )

        val model = GenerativeModel(
            modelName = "gemini-flash-latest",
            apiKey = BuildConfig.API_KEY,
            systemInstruction = content { text("Bạn là một trợ lý AI quản lý giao diện Android. Nhiệm vụ chính của bạn là đổi màu màn hình khi người dùng yêu cầu. Hãy ưu tiên dùng công cụ changeBackgroundColor.") },
            tools = listOf(Tool(listOf(changeColorTool)))
        )

        val chat = model.startChat()

        btnSend.setOnClickListener {
            val userText = edtInput.text.toString()
            if (userText.isBlank()) return@setOnClickListener

            tvAiResponse.text = "AI đang suy nghĩ..."
            edtInput.text.clear()

            lifecycleScope.launch {
                try {
                    val response = chat.sendMessage(userText)

                    val functionCall = response.functionCalls.firstOrNull()
                    if (functionCall != null) {
                        val color = functionCall.args["color"] as? String ?: "white"

                        runOnUiThread {
                            val colorCode = getColorCode(color)
                            rootLayout.setBackgroundColor(colorCode)
                        }

                        val functionResponse = content {
                            part(FunctionResponsePart(
                                name = functionCall.name,
                                response = JSONObject(mapOf("status" to "success", "color" to color))
                            ))
                        }

                        val finalResponse = chat.sendMessage(functionResponse)
                        tvAiResponse.text = "AI: ${finalResponse.text}"
                    } else {
                        tvAiResponse.text = "AI: ${response.text}"
                    }

                } catch (e: Exception) {
                    tvAiResponse.text = "Lỗi: ${e.message}"
                    e.printStackTrace()
                }
            }
        }
    }

    private fun getColorCode(colorName: String): Int {
        return when (colorName.lowercase()) {
            "red" -> Color.RED
            "blue" -> Color.BLUE
            "green" -> Color.GREEN
            "yellow" -> Color.YELLOW
            "white" -> Color.WHITE
            "black" -> Color.BLACK
            "gray", "grey" -> Color.GRAY
            "orange" -> Color.parseColor("#FFA500")
            "purple" -> Color.parseColor("#800080")
            "pink" -> Color.parseColor("#FFC0CB")
            else -> Color.WHITE
        }
    }
}


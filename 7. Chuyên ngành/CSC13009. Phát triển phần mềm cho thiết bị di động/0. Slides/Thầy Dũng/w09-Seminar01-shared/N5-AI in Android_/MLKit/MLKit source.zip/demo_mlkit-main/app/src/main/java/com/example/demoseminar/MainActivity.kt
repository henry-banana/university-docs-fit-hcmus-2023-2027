package com.example.demoseminar

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var tvRawLabel: TextView
    private lateinit var tvTrashType: TextView

    // ML Kit labeler
    val labeler = ImageLabeling.getClient(
        ImageLabelerOptions.Builder()
            .setConfidenceThreshold(0.5f)
            .build()
    )


    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val uri = result.data?.data
                if (uri != null) {
                    handleImageUri(uri)
                } else {
                    Toast.makeText(this, "Không lấy được ảnh", Toast.LENGTH_SHORT).show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        tvRawLabel = findViewById(R.id.tvRawLabel)
        tvTrashType = findViewById(R.id.tvTrashType)

        val btnSelect: Button = findViewById(R.id.btnSelect)
        btnSelect.setOnClickListener {
            openGallery()
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
        }
        pickImageLauncher.launch(intent)
    }

    private fun handleImageUri(uri: Uri) {
        val bitmap = uriToBitmap(uri) ?: run {
            Toast.makeText(this, "Không đọc được ảnh", Toast.LENGTH_SHORT).show()
            return
        }

        imageView.setImageBitmap(bitmap)
        runImageLabeling(bitmap)
    }

    private fun uriToBitmap(uri: Uri): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(source)
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun runImageLabeling(bitmap: Bitmap) {
        val image = InputImage.fromBitmap(bitmap, 0)

        labeler.process(image)
            .addOnSuccessListener { labels ->
                if (labels.isEmpty()) {
                    tvRawLabel.text = "Không nhận diện được nhãn nào"
                    tvTrashType.text = ""
                    return@addOnSuccessListener
                }

                val resultText = labels.joinToString("\n") { label ->
                    "${label.text} (%.2f)".format(label.confidence)
                }

                tvRawLabel.text = resultText

                tvTrashType.text = ""
            }
            .addOnFailureListener { e ->
                e.printStackTrace()
                Toast.makeText(this, "Lỗi ML Kit: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}

package com.example.demo_nav_toolbar

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.os.bundleOf
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout
    private lateinit var adapter: ViewPagerAdapter
    private lateinit var navController: NavController
    private lateinit var navHostFragment: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Setup Toolbar
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)


        supportActionBar?.title = "Demo Nav & Toolbar"
        // Initially hide back button when on main screen with TabLayout
        supportActionBar?.setDisplayHomeAsUpEnabled(false)

        // Setup ViewPager2 and TabLayout
        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)
        navHostFragment = findViewById(R.id.nav_host_fragment)

        adapter = ViewPagerAdapter(this)
        viewPager.adapter = adapter

        // Link TabLayout with ViewPager2
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = adapter.getPageTitle(position)
        }.attach()

        // Setup Navigation Component
        val navHost = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHost.navController

        // Listen to navigation destination changes
        navController.addOnDestinationChangedListener { _, destination, _ ->
            // Check if we're navigating to any fragment (not on main screen)
            updateBackButton(destination.id in listOf(
                R.id.homeFragment,
                R.id.contextFragment,
                R.id.camFragment,
                R.id.popupFragment
            ))
        }

        // Handle back press using OnBackPressedDispatcher
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (navHostFragment.visibility == View.VISIBLE &&
                    navController.currentDestination?.id != R.id.mainTabFragment) {
                    navController.navigateUp()
                } else {
                    // On main screen, allow system to handle back press (exit app)
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun updateBackButton(isNavigated: Boolean) {
        if (isNavigated) {
            // Navigated to a fragment - show back button, hide TabLayout, show NavHost
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            viewPager.visibility = View.GONE
            tabLayout.visibility = View.GONE
            navHostFragment.visibility = View.VISIBLE
        } else {
            // On main screen - hide back button, show TabLayout, hide NavHost
            supportActionBar?.setDisplayHomeAsUpEnabled(false)
            viewPager.visibility = View.VISIBLE
            tabLayout.visibility = View.VISIBLE
            navHostFragment.visibility = View.GONE
            supportActionBar?.title = "Demo Nav & Toolbar"
        }
    }

    // ...existing code...

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    // ...existing code...

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.homeFragment -> {
                // Use Safe Args to pass arguments
                val bundle = bundleOf(
                    "userName" to "John Doe",
                    "userId" to 12345
                )
                navigateWithArgs(R.id.homeFragment, bundle, "Options Menu")
                true
            }
            R.id.contextFragment -> {
                val bundle = bundleOf(
                    "messageText" to "Hello from MainActivity!",
                    "timestamp" to System.currentTimeMillis()
                )
                navigateWithArgs(R.id.contextFragment, bundle, "Context Menu")
                true
            }
            R.id.camFragment -> {
                val bundle = bundleOf(
                    "itemCount" to 10,
                    "selectionMode" to true
                )
                navigateWithArgs(R.id.camFragment, bundle, "CAM")
                true
            }
            R.id.popupFragment -> {
                val bundle = bundleOf(
                    "popupTitle" to "Custom Popup Menu",
                    "itemPosition" to 3
                )
                navigateWithArgs(R.id.popupFragment, bundle, "Popup Menu")
                true
            }
            R.id.action_search -> {
                Toast.makeText(this, "Search clicked", Toast.LENGTH_SHORT).show()
                true
            }
            android.R.id.home -> {
                // Handle back navigation
                navController.navigateUp()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun navigateWithArgs(destinationId: Int, bundle: Bundle, title: String) {
        // Show NavHostFragment and hide ViewPager
        navHostFragment.visibility = View.VISIBLE
        viewPager.visibility = View.GONE
        tabLayout.visibility = View.GONE

        // Navigate using NavController with arguments
        navController.navigate(destinationId, bundle)

        // Update toolbar title
        supportActionBar?.title = title
        Toast.makeText(this, "Navigating to $title with Safe Args", Toast.LENGTH_SHORT).show()
    }
}


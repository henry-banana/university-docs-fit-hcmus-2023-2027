package com.example.demo_nav_toolbar

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast

// ============ 1. OPTIONS MENU / ACTION BAR ============
// Fragment này demo Options Menu
// Options Menu được implement trong MainActivity.kt với:
// - onCreateOptionsMenu(): inflate menu từ main_menu.xml
// - onOptionsItemSelected(): xử lý khi user click menu item
// Menu hiển thị ở Action Bar (3 chấm góc phải trên)

class HomeFragment : Fragment() {

    /**
     * Tạo và khởi tạo giao diện của Fragment
     *
     * @param inflater - LayoutInflater để chuyển XML thành View object
     * @param container - ViewGroup cha chứa Fragment
     * @param savedInstanceState - Bundle chứa trạng thái đã lưu (nếu có)
     * @return View - Giao diện của fragment
     *
     * Chức năng:
     * - Inflate layout fragment_home.xml
     * - Nhận dữ liệu từ Safe Args (userName, userId)
     * - Hiển thị Toast thông báo dữ liệu nhận được nếu userId != 0
     * - Demo Options Menu được implement trong MainActivity
     */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // NHẬN DỮ LIỆU TỪ SAFE ARGS
        val userName = arguments?.getString("userName") ?: "Guest"
        val userId = arguments?.getInt("userId") ?: 0

        // Hiển thị dữ liệu nhận được
        if (userId != 0) {
            Toast.makeText(
                requireContext(),
                "Safe Args received:\nUser: $userName\nID: $userId",
                Toast.LENGTH_LONG
            ).show()
        }

        return view
    }
}


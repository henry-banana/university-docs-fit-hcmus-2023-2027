package com.example.demo_nav_toolbar

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

// ============ 3. CONTEXTUAL ACTION MODE (CAM) ============
// Fragment này demo CAM - thanh action tạm thời khi chọn item
// CAM hiển thị thanh action ở top khi user chọn một hoặc nhiều item

class CAMFragment : Fragment() {

    private var actionMode: ActionMode? = null
    private val selectedItems = mutableSetOf<Int>()
    private lateinit var items: List<TextView>

    /**
     * Tạo và khởi tạo giao diện của Fragment
     *
     * @param inflater - LayoutInflater để chuyển file XML thành View object
     * @param container - ViewGroup cha chứa Fragment
     * @param savedInstanceState - Bundle chứa trạng thái đã lưu (nếu có)
     * @return View - Giao diện của fragment
     *
     * Chức năng:
     * - Inflate layout fragment_cam.xml
     * - Nhận dữ liệu từ Safe Args (selectedCount, isMultiSelectMode)
     * - Khởi tạo và setup 5 TextViews có thể chọn
     * - Gán click listener cho từng item
     * - Hiển thị Toast nếu có dữ liệu Safe Args
     */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_cam, container, false)

        // Nhận dữ liệu từ Safe Args
        val selectedCount = arguments?.getInt("selectedCount") ?: 0
        val isMultiSelectMode = arguments?.getBoolean("isMultiSelectMode") ?: false

        // Setup các item có thể chọn
        val tvItem1 = view.findViewById<TextView>(R.id.tvItem1)
        val tvItem2 = view.findViewById<TextView>(R.id.tvItem2)
        val tvItem3 = view.findViewById<TextView>(R.id.tvItem3)
        val tvItem4 = view.findViewById<TextView>(R.id.tvItem4)
        val tvItem5 = view.findViewById<TextView>(R.id.tvItem5)

        items = listOf(tvItem1, tvItem2, tvItem3, tvItem4, tvItem5)

        items.forEachIndexed { index, textView ->
            textView.setOnClickListener {
                toggleItemSelection(index, textView)
            }
        }

        // Hiển thị dữ liệu nhận được
        if (selectedCount > 0) {
            Toast.makeText(
                requireContext(),
                "Safe Args received:\nSelected: $selectedCount items\nMulti-Select: $isMultiSelectMode",
                Toast.LENGTH_LONG
            ).show()
        }

        return view
    }

    /**
     * Toggle (bật/tắt) trạng thái chọn của một item
     *
     * @param index - Vị trí của item trong danh sách (0-4)
     * @param view - TextView được click
     *
     * Chức năng:
     * - Nếu item đã được chọn: Bỏ chọn và đổi màu về màu gốc
     * - Nếu item chưa được chọn: Chọn và đổi màu thành xanh
     * - Cập nhật Contextual Action Mode:
     *   + Không còn item nào → Đóng CAM
     *   + Có item được chọn → Mở CAM và hiển thị số lượng
     */
    private fun toggleItemSelection(index: Int, view: TextView) {
        if (selectedItems.contains(index)) {
            // Bỏ chọn
            selectedItems.remove(index)
            view.setBackgroundColor(getOriginalColor(index))
        } else {
            // Chọn
            selectedItems.add(index)
            view.setBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.holo_blue_light))
        }

        // Cập nhật CAM
        if (selectedItems.isEmpty()) {
            actionMode?.finish()
        }
        else
        {
            if (actionMode == null)
            {
                actionMode = requireActivity()
                    .startActionMode(actionModeCallback)
            }
            actionMode?.title = "${selectedItems.size} selected"
        }
    }

    /**
     * Lấy màu nền ban đầu của item theo vị trí
     *
     * @param index - Vị trí của item (0-4)
     * @return Int - Resource ID của màu
     *
     * Màu sắc:
     * - Item 0: Cam (holo_orange_light)
     * - Item 1: Tím (holo_purple)
     * - Item 2: Xanh lá (holo_green_light)
     * - Item 3: Đỏ (holo_red_light)
     * - Item 4: Xanh dương (holo_blue_light)
     */
    private fun getOriginalColor(index: Int): Int {
        val colors = listOf(
            android.R.color.holo_orange_light,
            android.R.color.holo_purple,
            android.R.color.holo_green_light,
            android.R.color.holo_red_light,
            android.R.color.holo_blue_light
        )
        return ContextCompat.getColor(requireContext(), colors[index % colors.size])
    }

    /**
     * Callback xử lý các sự kiện của Contextual Action Mode
     */
    private val actionModeCallback = object : ActionMode.Callback {
        /**
         * Được gọi khi ActionMode được tạo lần đầu
         *
         * @param mode - Instance của ActionMode
         * @param menu - Menu object để inflate các menu items
         * @return Boolean - true nếu ActionMode được tạo thành công
         *
         * Chức năng: Inflate menu cam_menu.xml (Delete, Share, Edit)
         */
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            mode.menuInflater.inflate(R.menu.cam_menu, menu)
            return true
        }

        /**
         * Được gọi để refresh ActionMode
         *
         * @return Boolean - true nếu menu cần refresh
         *
         * Chức năng: Không làm gì (có thể dùng để ẩn/hiện menu items)
         */
        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
            return false
        }

        /**
         * Xử lý khi user click vào action item trong CAM
         *
         * @param mode - Instance của ActionMode
         * @param item - MenuItem được click
         * @return Boolean - true nếu xử lý thành công
         *
         * Actions: Delete, Share, Edit → Hiển thị Toast và đóng CAM
         */
        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            return when (item.itemId) {
                R.id.cam_delete -> {
                    showToast("Delete ${selectedItems.size} items")
                    clearSelection()
                    mode.finish()
                    true
                }
                R.id.cam_share -> {
                    showToast("Share ${selectedItems.size} items")
                    clearSelection()
                    mode.finish()
                    true
                }
                R.id.cam_edit -> {
                    showToast("Edit ${selectedItems.size} items")
                    clearSelection()
                    mode.finish()
                    true
                }
                else -> false
            }
        }

        /**
         * Được gọi khi ActionMode bị đóng
         *
         * @param mode - Instance của ActionMode
         *
         * Chức năng: Set actionMode = null và clear selections
         */
        override fun onDestroyActionMode(mode: ActionMode) {
            actionMode = null
            clearSelection()
        }
    }

    /**
     * Xóa tất cả selections và reset màu nền
     *
     * Chức năng:
     * - Duyệt qua tất cả items
     * - Đổi màu về màu gốc
     * - Clear set selectedItems
     */
    private fun clearSelection() {
        items.forEachIndexed { index, textView ->
            textView.setBackgroundColor(getOriginalColor(index))
        }
        selectedItems.clear()
    }

    /**
     * Hiển thị thông báo Toast
     *
     * @param message - Nội dung thông báo
     *
     * Chức năng: Hiển thị Toast với độ dài LENGTH_SHORT (2 giây)
     */
    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    /**
     * Được gọi khi View của Fragment bị destroy
     *
     * Chức năng: Đóng ActionMode để tránh memory leak
     */
    override fun onDestroyView() {
        super.onDestroyView()
        actionMode?.finish()
    }
}




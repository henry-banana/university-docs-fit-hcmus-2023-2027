package com.example.demo_nav_toolbar

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu

// ============ 4. POPUP MENU ============
// Fragment này demo Popup Menu - menu nhỏ gắn vào một View
// Popup Menu xuất hiện khi user click vào button hoặc icon

class PopupFragment : Fragment() {

    /**
     * Tạo và khởi tạo giao diện của Fragment
     *
     * @param inflater - LayoutInflater để chuyển XML thành View object
     * @param container - ViewGroup cha chứa Fragment
     * @param savedInstanceState - Bundle chứa trạng thái đã lưu (nếu có)
     * @return View - Giao diện của fragment
     *
     * Chức năng:
     * - Inflate layout fragment_popup.xml
     * - Nhận dữ liệu từ Safe Args: popupTitle (String), itemPosition (Int)
     * - Setup 3 buttons để hiển thị Popup Menu:
     *   + btnFileMenu → File operations menu
     *   + btnShareMenu → Share options menu (dynamic)
     *   + btnMoreMenu → More options menu
     * - Hiển thị Toast với title và position nếu itemPosition != -1
     */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_popup, container, false)

        // Nhận dữ liệu từ Safe Args
        val popupTitle = arguments?.getString("popupTitle") ?: "Popup Demo"
        val itemPosition = arguments?.getInt("itemPosition") ?: -1

        // Button 1 - File operations
        val btnFileMenu = view.findViewById<Button>(R.id.btnFileMenu)
        btnFileMenu.setOnClickListener {
            showPopupMenu(it, R.menu.popup_menu, "File Menu")
        }

        // Button 2 - Share options
        val btnShareMenu = view.findViewById<Button>(R.id.btnShareMenu)
        btnShareMenu.setOnClickListener {
            showSharePopupMenu(it)
        }

        // Button 3 - More options
        val btnMoreMenu = view.findViewById<Button>(R.id.btnMoreMenu)
        btnMoreMenu.setOnClickListener {
            showPopupMenu(it, R.menu.popup_menu, "More Options")
        }

        // Hiển thị dữ liệu nhận được
        if (itemPosition != -1) {
            Toast.makeText(
                requireContext(),
                "Safe Args received:\nTitle: $popupTitle\nPosition: $itemPosition",
                Toast.LENGTH_LONG
            ).show()
        }

        return view
    }

    /**
     * Hiển thị Popup Menu cơ bản
     * 
     * @param anchorView - View mà menu sẽ gắn vào (button)
     * @param menuRes - Resource ID của menu XML
     * @param title - Title prefix cho Toast message
     * 
     * Chức năng:
     * - Tạo PopupMenu gắn vào anchorView
     * - Inflate menu từ popup_menu.xml
     * - Xử lý 3 actions: Refresh, Export, Info
     * - Hiển thị Toast khi click vào menu item
     * - Gọi popup.show() để hiển thị menu
     */
    private fun showPopupMenu(anchorView: View, menuRes: Int, title: String) {
        val popup = PopupMenu(requireContext(), anchorView)
        popup.menuInflater.inflate(menuRes, popup.menu)

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.popup_refresh -> {
                    showToast("$title: Refresh")
                    true
                }
                R.id.popup_export -> {
                    showToast("$title: Export")
                    true
                }
                R.id.popup_info -> {
                    showToast("$title: Info")
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    /**
     * Hiển thị Popup Menu cho Share options (menu động)
     * 
     * @param anchorView - View mà menu sẽ gắn vào (button)
     * 
     * Chức năng:
     * - Tạo PopupMenu gắn vào anchorView
     * - Tạo menu động (không dùng XML) với 4 options:
     *   + Share via Email
     *   + Share via Message
     *   + Share via Social Media
     *   + Copy Link
     * - Xử lý click cho từng option và hiển thị Toast
     */
    private fun showSharePopupMenu(anchorView: View) {
        val popup = PopupMenu(requireContext(), anchorView)

        // Tạo menu động
        popup.menu.add(0, 1, 0, "Share via Email")
        popup.menu.add(0, 2, 1, "Share via Message")
        popup.menu.add(0, 3, 2, "Share via Social Media")
        popup.menu.add(0, 4, 3, "Copy Link")

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> showToast("Share via Email")
                2 -> showToast("Share via Message")
                3 -> showToast("Share via Social Media")
                4 -> showToast("Copy Link")
            }
            true
        }
        popup.show()
    }

    /**
     * Hiển thị thông báo Toast
     * 
     * @param message - Nội dung thông báo
     */
    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }
}


package com.example.demo_nav_toolbar

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ContextMenu
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast

// ============ 2. CONTEXT MENU ============
// Fragment này demo Context Menu (long-press menu)
// Context Menu xuất hiện khi user bấm giữ (long-press) vào một View đã đăng ký
class ContextFragment : Fragment() {

    /**
     * Tạo và khởi tạo giao diện của Fragment
     *
     * @param inflater - LayoutInflater để chuyển XML thành View object
     * @param container - ViewGroup cha chứa Fragment
     * @param savedInstanceState - Bundle chứa trạng thái đã lưu (nếu có)
     * @return View - Giao diện của fragment
     *
     * Chức năng:
     * - Inflate layout fragment_context.xml
     * - Nhận dữ liệu từ Safe Args: messageText (String), timestamp (Long)
     * - Đăng ký Context Menu cho 3 TextViews (tvContextMenu1, 2, 3)
     * - Hiển thị Toast với message và thời gian nếu timestamp != 0
     */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_context, container, false)

        // Nhận dữ liệu từ Safe Args
        val messageText = arguments?.getString("messageText") ?: "No message"
        val timestamp = arguments?.getLong("timestamp") ?: 0L

        // Đăng ký Context Menu cho các TextView
        val tvContextMenu1 = view.findViewById<TextView>(R.id.tvContextMenu1)
        val tvContextMenu2 = view.findViewById<TextView>(R.id.tvContextMenu2)
        val tvContextMenu3 = view.findViewById<TextView>(R.id.tvContextMenu3)
        registerForContextMenu(tvContextMenu1)
        registerForContextMenu(tvContextMenu2)
        registerForContextMenu(tvContextMenu3)

        // Hiển thị dữ liệu nhận được
        if (timestamp != 0L) {
            Toast.makeText(
                requireContext(),
                "Safe Args received:\n$messageText\nTime: ${java.text.SimpleDateFormat("HH:mm:ss").format(timestamp)}",
                Toast.LENGTH_LONG
            ).show()
        }

        return view
    }

    /**
     * Tạo Context Menu khi user long-press vào TextView
     *
     * @param menu - ContextMenu object để inflate menu items
     * @param v - View được long-press
     * @param menuInfo - Thông tin bổ sung về context menu
     *
     * Chức năng:
     * - Inflate menu context_menu.xml (Edit, Copy, Delete)
     * - Set header title dựa vào view được long-press:
     *   + tvContextMenu1 → "Options for Document 1"
     *   + tvContextMenu2 → "Options for Document 2"
     *   + tvContextMenu3 → "Options for Document 3"
     */
    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        requireActivity().menuInflater.inflate(R.menu.context_menu, menu)

        // Set header title dựa trên view nào được giữ
        val title = when (v.id) {
            R.id.tvContextMenu1 -> "Options for Document 1"
            R.id.tvContextMenu2 -> "Options for Document 2"
            R.id.tvContextMenu3 -> "Options for Document 3"
            else -> "Context Menu"
        }
        menu.setHeaderTitle(title)
    }

    /**
     * Xử lý khi user click vào item trong Context Menu
     *
     * @param item - MenuItem được click
     * @return Boolean - true nếu xử lý thành công
     *
     * Chức năng:
     * - Xử lý 3 actions:
     *   + context_edit → Hiển thị Toast "Edit clicked"
     *   + context_copy → Hiển thị Toast "Copy clicked"
     *   + context_delete → Hiển thị Toast "Delete clicked"
     */
    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.context_edit -> {
                showToast("Edit clicked")
                true
            }
            R.id.context_copy -> {
                showToast("Copy clicked")
                true
            }
            R.id.context_delete -> {
                showToast("Delete clicked")
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    /**
     * Hiển thị thông báo Toast
     *
     * @param message - Nội dung thông báo
     */
    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }
}



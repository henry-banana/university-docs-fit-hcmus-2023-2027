package com.example.demo_nav_toolbar

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class ViewPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

    private val titles = listOf(
        "Options Menu",
        "Context Menu",
        "CAM",
        "Popup Menu"
    )

    override fun getItemCount(): Int = 4

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> HomeFragment()
            1 -> ContextFragment()
            2 -> CAMFragment()
            3 -> PopupFragment()
            else -> HomeFragment()
        }
    }

    fun getPageTitle(position: Int): String = titles[position]
}


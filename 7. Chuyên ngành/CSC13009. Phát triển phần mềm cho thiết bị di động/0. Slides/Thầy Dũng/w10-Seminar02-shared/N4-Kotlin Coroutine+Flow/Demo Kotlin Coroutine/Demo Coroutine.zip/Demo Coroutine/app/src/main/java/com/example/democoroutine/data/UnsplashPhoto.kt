package com.example.democoroutine.data

import com.google.gson.annotations.SerializedName

/**
 * Data model cho Unsplash Photo
 */
data class UnsplashPhoto(
    val id: String,
    @SerializedName("created_at")
    val createdAt: String,
    val width: Int,
    val height: Int,
    val description: String?,
    @SerializedName("alt_description")
    val altDescription: String?,
    val urls: PhotoUrls,
    val user: User
)

data class PhotoUrls(
    val raw: String,
    val full: String,
    val regular: String,
    val small: String,
    val thumb: String
)

data class User(
    val id: String,
    val username: String,
    val name: String,
    @SerializedName("profile_image")
    val profileImage: ProfileImage
)

data class ProfileImage(
    val small: String,
    val medium: String,
    val large: String
)

/**
 * Response từ search API
 */
data class UnsplashSearchResponse(
    val total: Int,
    @SerializedName("total_pages")
    val totalPages: Int,
    val results: List<UnsplashPhoto>
)

package com.example.democoroutine.network

import com.example.democoroutine.data.UnsplashPhoto
import com.example.democoroutine.data.UnsplashSearchResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Unsplash API interface
 * API Key: Demo key - trong production nên dùng key riêng
 */
interface UnsplashApi {
    
    /**
     * Get random photos
     */
    @GET("photos/random")
    suspend fun getRandomPhotos(
        @Query("count") count: Int = 10,
        @Query("client_id") clientId: String = API_KEY
    ): List<UnsplashPhoto>
    
    /**
     * Search photos
     */
    @GET("search/photos")
    suspend fun searchPhotos(
        @Query("query") query: String,
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 10,
        @Query("client_id") clientId: String = API_KEY
    ): UnsplashSearchResponse
    
    companion object {
        const val BASE_URL = "https://api.unsplash.com/"
        // Demo API Key - có rate limit thấp
        // Trong production, hãy tạo key riêng tại: https://unsplash.com/developers
        // Nếu bị lỗi 401, hãy thay bằng API key của bạn
        const val API_KEY = "4Ryw9IGKvj9-9T6y5b0nNgQ2Nq0wFP_n0Rly75UIuvY"
        
        // Alternative demo keys (rotate if one fails):
        // "ckhn2iWN7VhFQc-HwzxRp8W_m2U3dbtDZpRB_UNvdvY"
        // "cXUAQaHfqCZwNoOUe8cmP0hHqJOvWf5OqZOUkLKaLCo"
    }
}

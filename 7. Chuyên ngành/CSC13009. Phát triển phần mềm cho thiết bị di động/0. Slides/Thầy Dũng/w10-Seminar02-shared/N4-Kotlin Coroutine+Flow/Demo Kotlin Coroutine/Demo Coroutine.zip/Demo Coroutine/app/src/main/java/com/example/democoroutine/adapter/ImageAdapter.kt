package com.example.democoroutine.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.democoroutine.R
import com.example.democoroutine.data.UnsplashPhoto

/**
 * Adapter cho RecyclerView hiển thị ảnh từ Unsplash
 */
class ImageAdapter(
    private var photos: List<UnsplashPhoto>,
    private val onDownloadClick: (UnsplashPhoto, Int) -> Unit
) : RecyclerView.Adapter<ImageAdapter.PhotoViewHolder>() {

    // Track download status for each photo
    private val downloadProgress = mutableMapOf<String, Int>()
    private val downloadStatus = mutableMapOf<String, DownloadStatus>()

    enum class DownloadStatus {
        IDLE, DOWNLOADING, COMPLETED, CANCELLED, ERROR
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_photo, parent, false)
        return PhotoViewHolder(view)
    }

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        val photo = photos[position]
        holder.bind(photo)
    }

    override fun getItemCount() = photos.size

    /**
     * Update danh sách photos
     */
    fun updatePhotos(newPhotos: List<UnsplashPhoto>) {
        photos = newPhotos
        downloadProgress.clear()
        downloadStatus.clear()
        notifyDataSetChanged()
    }

    /**
     * Update download progress cho một photo
     */
    fun updateDownloadProgress(photoId: String, progress: Int) {
        downloadProgress[photoId] = progress
        val position = photos.indexOfFirst { it.id == photoId }
        if (position != -1) {
            notifyItemChanged(position)
        }
    }

    /**
     * Update download status
     */
    fun updateDownloadStatus(photoId: String, status: DownloadStatus) {
        downloadStatus[photoId] = status
        val position = photos.indexOfFirst { it.id == photoId }
        if (position != -1) {
            notifyItemChanged(position)
        }
    }

    /**
     * Reset tất cả download status
     */
    fun resetAllDownloads() {
        downloadProgress.clear()
        downloadStatus.clear()
        notifyDataSetChanged()
    }

    /**
     * Get download status cho một photo
     */
    fun getDownloadStatus(photoId: String): DownloadStatus {
        return downloadStatus[photoId] ?: DownloadStatus.IDLE
    }

    inner class PhotoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivPhoto: ImageView = itemView.findViewById(R.id.ivPhoto)
        private val tvDescription: TextView = itemView.findViewById(R.id.tvDescription)
        private val tvPhotographer: TextView = itemView.findViewById(R.id.tvPhotographer)
        private val btnDownload: Button = itemView.findViewById(R.id.btnDownload)
        private val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
        private val tvProgress: TextView = itemView.findViewById(R.id.tvProgress)
        private val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)

        fun bind(photo: UnsplashPhoto) {
            // Load image với Coil
            ivPhoto.load(photo.urls.small) {
                crossfade(true)
                placeholder(R.drawable.ic_launcher_background)
            }

            // Set description
            tvDescription.text = photo.altDescription ?: photo.description ?: "Untitled"

            // Set photographer name
            tvPhotographer.text = "By ${photo.user.name}"

            // Get current status and progress
            val status = downloadStatus[photo.id] ?: DownloadStatus.IDLE
            val progress = downloadProgress[photo.id] ?: 0

            // Update UI based on status
            when (status) {
                DownloadStatus.IDLE -> {
                    btnDownload.isEnabled = true
                    btnDownload.text = "Download"
                    progressBar.visibility = View.GONE
                    tvProgress.visibility = View.GONE
                    tvStatus.visibility = View.GONE
                }
                DownloadStatus.DOWNLOADING -> {
                    btnDownload.isEnabled = false
                    btnDownload.text = "Downloading..."
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = progress
                    tvProgress.visibility = View.VISIBLE
                    tvProgress.text = "$progress%"
                    tvStatus.visibility = View.GONE
                }
                DownloadStatus.COMPLETED -> {
                    btnDownload.isEnabled = false
                    btnDownload.text = "Downloaded ✓"
                    progressBar.visibility = View.GONE
                    tvProgress.visibility = View.GONE
                    tvStatus.visibility = View.VISIBLE
                    tvStatus.text = "Completed!"
                    tvStatus.setTextColor(itemView.context.getColor(android.R.color.holo_green_dark))
                }
                DownloadStatus.CANCELLED -> {
                    btnDownload.isEnabled = true
                    btnDownload.text = "Download"
                    progressBar.visibility = View.GONE
                    tvProgress.visibility = View.GONE
                    tvStatus.visibility = View.VISIBLE
                    tvStatus.text = "Cancelled"
                    tvStatus.setTextColor(itemView.context.getColor(android.R.color.holo_red_dark))
                }
                DownloadStatus.ERROR -> {
                    btnDownload.isEnabled = true
                    btnDownload.text = "Retry"
                    progressBar.visibility = View.GONE
                    tvProgress.visibility = View.GONE
                    tvStatus.visibility = View.VISIBLE
                    tvStatus.text = "Error"
                    tvStatus.setTextColor(itemView.context.getColor(android.R.color.holo_red_dark))
                }
            }

            // Download button click
            btnDownload.setOnClickListener {
                onDownloadClick(photo, adapterPosition)
            }
        }
    }
}

# 📸 Image Gallery Demo - Kotlin Coroutines

## 🎯 Mục đích

Ứng dụng Android demo **thực tế** về Kotlin Coroutines thông qua việc:
- Load ảnh từ **Unsplash API**
- Download nhiều ảnh **song song** với Coroutines
- Hiển thị **progress realtime** cho từng ảnh
- **Cancel downloads** bất cứ lúc nào

## ✨ Tính năng

### 🔄 Load Images
- Gọi Unsplash API để lấy 10 ảnh random
- Hiển thị trong RecyclerView với thông tin photographer
- Demo **suspend function** với Retrofit

### ⬇️ Download Images
- **Download từng ảnh**: Bấm nút Download trên mỗi ảnh
- **Download All**: Download tất cả ảnh **song song** (parallel)
- Mỗi ảnh có:
  - Progress bar riêng (0-100%)
  - Progress percentage
  - Status (Downloading/Completed/Cancelled/Error)

### ❌ Cancel Downloads
- Cancel một download đang chạy
- Cancel tất cả downloads cùng lúc
- Demo **Job cancellation** trong Coroutines

## 🔍 Điểm nổi bật demo Coroutines

### 1. **Parallel Downloads** ⚡
```kotlin
// Download tất cả ảnh song song!
photos.forEach { photo ->
    downloadImage(photo) // Mỗi ảnh là một coroutine riêng
}
```
**Thấy rõ**: Tất cả ảnh download cùng lúc, không phải tuần tự

### 2. **Progress Tracking** 📊
```kotlin
// Update progress trong coroutine
withContext(Dispatchers.Main) {
    imageAdapter.updateDownloadProgress(photo.id, progress)
}
```
**Thấy rõ**: Progress bar update realtime mà không block UI

### 3. **Suspend Functions** ⏸️
```kotlin
// API call với suspend function
suspend fun getRandomPhotos(): List<UnsplashPhoto>
```
**Thấy rõ**: Gọi API đơn giản như code synchronous

### 4. **Job Management** 🎛️
```kotlin
val job = lifecycleScope.launch { ... }
downloadJobs[photo.id] = job
// Sau đó cancel:
job.cancel()
```
**Thấy rõ**: Quản lý và cancel từng task dễ dàng

### 5. **Context Switching** 🔄
```kotlin
withContext(Dispatchers.IO) {
    // Network/File operations
}
withContext(Dispatchers.Main) {
    // UI updates
}
```
**Thấy rõ**: Switch giữa IO và Main thread tự nhiên

## 🚀 Hướng dẫn chạy

### Bước 1: Sync Dependencies
```
File → Sync Project with Gradle Files
```

### Bước 2: Chạy app
1. Build and Run trên emulator hoặc thiết bị thật
2. Cấp quyền Internet (tự động)
3. Cấp quyền Storage nếu Android 13+ (app sẽ hỏi)

### Bước 3: Demo
1. **Bấm "Load Images"** → Xem ảnh load từ Unsplash
2. **Bấm "Download All"** → Thấy tất cả ảnh download song song
3. **Quan sát progress bars** → Thấy mỗi ảnh download với tốc độ khác nhau
4. **Bấm "Cancel"** → Tất cả downloads dừng ngay

## 📱 Screenshots Flow

### 1. Initial State
```
- Empty state: "Bấm 'Load Images' để tải ảnh"
- Status: "Ready to load images"
```

### 2. After Load Images
```
- RecyclerView với 10 ảnh
- Mỗi ảnh có: Thumbnail, Description, Photographer, Download button
```

### 3. During Download All
```
- Tất cả ảnh hiển thị progress bars
- Progress % update realtime
- Buttons disabled
```

### 4. After Download Complete
```
- Buttons chuyển thành "Downloaded ✓"
- Status: "X/10 downloaded"
- Có thể cancel và download lại
```

## 🎓 Concepts được demo

### ✅ Coroutines Basics
- `lifecycleScope.launch` - Lifecycle-aware coroutines
- `suspend fun` - Suspend functions
- `delay()` - Non-blocking delay

### ✅ Parallel Execution
- Multiple coroutines chạy đồng thời
- So sánh với sequential execution
- Hiệu suất tốt hơn

### ✅ Progress Tracking
- Update UI trong coroutine
- `withContext(Dispatchers.Main)` cho UI updates
- Real-time feedback

### ✅ Cancellation
- Cancel individual jobs
- Cancel all jobs
- Proper resource cleanup

### ✅ Context Switching
- `Dispatchers.IO` cho network/file operations
- `Dispatchers.Main` cho UI updates
- Seamless switching

### ✅ Error Handling
- Try-catch trong coroutines
- Handle `CancellationException`
- User feedback với Toast

## 🔧 Tech Stack

- **Language**: Kotlin
- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 36

### Dependencies
- **Kotlin Coroutines** (1.7.3) - Async programming
- **Retrofit** (2.9.0) - REST API calls
- **Coil** (2.5.0) - Image loading
- **OkHttp** (4.12.0) - HTTP client
- **Gson** (2.10.1) - JSON parsing
- **Material Design** - Modern UI

## 📊 Performance

### Parallel vs Sequential Download
```
10 ảnh, mỗi ảnh ~2-3 giây:

Sequential: 20-30 giây (từng ảnh một)
Parallel:   2-3 giây (tất cả cùng lúc)

Tăng tốc: ~10x! 🚀
```

## 🎬 Kịch bản demo (5 phút)

### Phút 1: Giới thiệu
"App này demo Coroutines qua việc download ảnh từ Unsplash"

### Phút 2: Load Images
- Bấm Load Images
- Giải thích: "Gọi API với suspend function"
- Thấy ảnh load vào RecyclerView

### Phút 3: Download một ảnh
- Bấm Download trên một ảnh
- Chỉ vào: Progress bar update realtime
- Giải thích: "Coroutine chạy trên IO dispatcher, update UI trên Main"

### Phút 4: Download All - Highlight chính!
- Bấm Download All
- Chỉ vào: "Tất cả ảnh download song song!"
- So sánh: "Nếu tuần tự sẽ mất 20-30s, song song chỉ 2-3s"

### Phút 5: Cancellation
- Bấm Download All
- Giữa chừng bấm Cancel
- "Downloads dừng ngay! Lifecycle-aware, tự động cleanup"

## ⚠️ Lưu ý

### API Key
App sử dụng demo API key của Unsplash có **rate limit thấp** (50 requests/hour).

Trong production, tạo key riêng tại: https://unsplash.com/developers

### Permissions
- Android 13+: App tự động lưu vào Downloads folder (không cần permission)
- Android 12-: Cần WRITE_EXTERNAL_STORAGE (đã khai báo)

### Network
Cần kết nối Internet để load và download ảnh.

## 🎯 So sánh với cách cũ

### ❌ Cách cũ (AsyncTask/Callbacks)
```kotlin
// Callback hell
downloadImage1 { result1 ->
    downloadImage2 { result2 ->
        downloadImage3 { result3 ->
            updateUI() // Deeply nested!
        }
    }
}
```

### ✅ Với Coroutines
```kotlin
// Clean, sequential code
lifecycleScope.launch {
    val result1 = downloadImage1()
    val result2 = downloadImage2()
    val result3 = downloadImage3()
    updateUI() // Flat structure!
}
```

## 💡 Bài học

1. **Coroutines giúp code đơn giản hơn** - Không còn callback hell
2. **Parallel execution dễ dàng** - Chỉ cần launch nhiều coroutines
3. **UI update trực tiếp** - withContext(Main) thay vì runOnUiThread
4. **Lifecycle-aware** - Tự động cancel khi Activity destroy
5. **Cancellation dễ dàng** - job.cancel() là xong

## 🚀 Mở rộng

### Có thể thêm:
- [ ] Search ảnh từ Unsplash
- [ ] Pagination (infinite scroll)
- [ ] Retry failed downloads
- [ ] Download queue management
- [ ] Offline caching với Room
- [ ] Share downloaded images

## 📚 Resources

- [Kotlin Coroutines Guide](https://kotlinlang.org/docs/coroutines-guide.html)
- [Android Coroutines Best Practices](https://developer.android.com/kotlin/coroutines)
- [Unsplash API Docs](https://unsplash.com/documentation)

---

**Created for**: Educational/Training purposes  
**Date**: December 21, 2025  
**Perfect for**: Coroutines workshops, technical presentations, learning materials

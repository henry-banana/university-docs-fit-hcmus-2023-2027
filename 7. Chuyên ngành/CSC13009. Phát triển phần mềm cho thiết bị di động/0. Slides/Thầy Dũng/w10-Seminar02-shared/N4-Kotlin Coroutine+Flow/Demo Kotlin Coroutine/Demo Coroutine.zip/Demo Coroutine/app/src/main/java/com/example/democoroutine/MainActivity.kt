package com.example.democoroutine

import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.democoroutine.adapter.ImageAdapter
import com.example.democoroutine.data.UnsplashPhoto
import com.example.democoroutine.network.RetrofitClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL

class MainActivity : AppCompatActivity() {

    // UI Components
    private lateinit var btnLoadImages: Button
    private lateinit var btnDownloadAll: Button
    private lateinit var btnCancelAll: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvDownloadCount: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressLoading: ProgressBar
    private lateinit var tvEmptyState: TextView

    // Adapter
    private lateinit var imageAdapter: ImageAdapter

    // Data
    private var photos = listOf<UnsplashPhoto>()

    // Download Jobs
    private val downloadJobs = mutableMapOf<String, Job>()
    private var downloadedCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupRecyclerView()
        setupListeners()
    }

    private fun initViews() {
        btnLoadImages = findViewById(R.id.btnLoadImages)
        btnDownloadAll = findViewById(R.id.btnDownloadAll)
        btnCancelAll = findViewById(R.id.btnCancelAll)
        tvStatus = findViewById(R.id.tvStatus)
        tvDownloadCount = findViewById(R.id.tvDownloadCount)
        recyclerView = findViewById(R.id.recyclerView)
        progressLoading = findViewById(R.id.progressLoading)
        tvEmptyState = findViewById(R.id.tvEmptyState)
    }

    private fun setupRecyclerView() {
        imageAdapter = ImageAdapter(photos) { photo, position ->
            downloadImage(photo)
        }
        recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = imageAdapter
        }
    }

    private fun setupListeners() {
        btnLoadImages.setOnClickListener { loadImages() }
        btnDownloadAll.setOnClickListener { downloadAllImages() }
        btnCancelAll.setOnClickListener { cancelAllDownloads() }
    }

    /**
     * Load ảnh từ Unsplash API
     */
    private fun loadImages() {
        lifecycleScope.launch {
            try {
                updateStatus("Loading images from Unsplash...", "#3498DB")
                progressLoading.visibility = View.VISIBLE
                tvEmptyState.visibility = View.GONE

                // Gọi API
                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.unsplashApi.getRandomPhotos(count = 10)
                }

                // Update UI
                photos = response
                imageAdapter.updatePhotos(photos)
                
                progressLoading.visibility = View.GONE
                
                if (photos.isEmpty()) {
                    tvEmptyState.visibility = View.VISIBLE
                    updateStatus("No images found", "#E74C3C")
                } else {
                    tvEmptyState.visibility = View.GONE
                    updateStatus("Loaded ${photos.size} images ✓", "#27AE60")
                    updateDownloadCount()
                    Toast.makeText(this@MainActivity, 
                        "Loaded ${photos.size} images!", 
                        Toast.LENGTH_SHORT).show()
                }

            } catch (e: Exception) {
                progressLoading.visibility = View.GONE
                tvEmptyState.visibility = View.VISIBLE
                
                val errorMessage = when {
                    e.message?.contains("401") == true || e.message?.contains("Unauthorized") == true -> {
                        "API Key không hợp lệ! Hãy tạo API key miễn phí tại:\nhttps://unsplash.com/developers"
                    }
                    e.message?.contains("403") == true -> {
                        "Rate limit exceeded. Vui lòng chờ vài phút."
                    }
                    e.message?.contains("Unable to resolve host") == true -> {
                        "Không có kết nối Internet"
                    }
                    else -> "Error: ${e.message}"
                }
                
                updateStatus(errorMessage, "#E74C3C")
                Toast.makeText(this@MainActivity, errorMessage, Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Download một ảnh với progress tracking
     */
    private fun downloadImage(photo: UnsplashPhoto) {
        // Cancel existing download job if any
        downloadJobs[photo.id]?.cancel()

        val job = lifecycleScope.launch {
            try {
                imageAdapter.updateDownloadStatus(photo.id, ImageAdapter.DownloadStatus.DOWNLOADING)
                
                // Download với progress updates
                withContext(Dispatchers.IO) {
                    val url = URL(photo.urls.regular)
                    val connection = url.openConnection()
                    connection.connect()
                    
                    val fileSize = connection.contentLength
                    val inputStream = connection.getInputStream()
                    
                    // Create file in Downloads folder
                    val fileName = "unsplash_${photo.id}.jpg"
                    val downloadDir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS
                    )
                    val file = File(downloadDir, fileName)
                    
                    val outputStream = FileOutputStream(file)
                    val buffer = ByteArray(4096)
                    var totalBytesRead = 0L
                    var bytesRead: Int

                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        outputStream.write(buffer, 0, bytesRead)
                        totalBytesRead += bytesRead
                        
                        // Calculate and update progress
                        val progress = ((totalBytesRead * 100) / fileSize).toInt()
                        
                        // Update UI on Main thread
                        withContext(Dispatchers.Main) {
                            imageAdapter.updateDownloadProgress(photo.id, progress)
                        }
                        
                        // Small delay để thấy rõ progress (có thể bỏ trong production)
                        delay(50)
                    }

                    outputStream.flush()
                    outputStream.close()
                    inputStream.close()
                }

                // Download completed
                imageAdapter.updateDownloadStatus(photo.id, ImageAdapter.DownloadStatus.COMPLETED)
                downloadedCount++
                updateDownloadCount()
                
                Toast.makeText(this@MainActivity, 
                    "Downloaded: ${photo.altDescription ?: "Image"}", 
                    Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) {
                    imageAdapter.updateDownloadStatus(photo.id, ImageAdapter.DownloadStatus.CANCELLED)
                } else {
                    imageAdapter.updateDownloadStatus(photo.id, ImageAdapter.DownloadStatus.ERROR)
                    Toast.makeText(this@MainActivity, 
                        "Download failed: ${e.message}", 
                        Toast.LENGTH_SHORT).show()
                }
            } finally {
                downloadJobs.remove(photo.id)
            }
        }

        downloadJobs[photo.id] = job
    }

    /**
     * Download tất cả ảnh song song
     * Demo sức mạnh của Coroutines!
     */
    private fun downloadAllImages() {
        if (photos.isEmpty()) {
            Toast.makeText(this, "Load images first!", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            updateStatus("Downloading ${photos.size} images in parallel...", "#9B59B6")
            
            // Download tất cả song song!
            photos.forEach { photo ->
                // Chỉ download những ảnh chưa download
                val currentStatus = imageAdapter.getDownloadStatus(photo.id)
                    
                if (currentStatus != ImageAdapter.DownloadStatus.COMPLETED) {
                    downloadImage(photo)
                }
            }

            Toast.makeText(this@MainActivity, 
                "Started downloading ${photos.size} images!", 
                Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Cancel tất cả downloads
     */
    private fun cancelAllDownloads() {
        downloadJobs.values.forEach { it.cancel() }
        downloadJobs.clear()
        imageAdapter.resetAllDownloads()
        downloadedCount = 0
        updateDownloadCount()
        updateStatus("All downloads cancelled", "#E74C3C")
        Toast.makeText(this, "Cancelled all downloads", Toast.LENGTH_SHORT).show()
    }

    /**
     * Update status text
     */
    private fun updateStatus(status: String, colorHex: String) {
        tvStatus.text = status
        tvStatus.setTextColor(android.graphics.Color.parseColor(colorHex))
    }

    /**
     * Update download count
     */
    private fun updateDownloadCount() {
        tvDownloadCount.text = "$downloadedCount/${photos.size} downloaded"
    }

    override fun onDestroy() {
        super.onDestroy()
        cancelAllDownloads()
    }
}